// spaceship.cpp
// Asteroid Game Engine version 1
// 15003814
// Last modified 07/01/2019

#include "gamecode.h"
#include "mydrawengine.h"
#include "mysoundengine.h"
#include "myinputs.h"
#include <time.h>
#include "gametimer.h"
#include "errorlogger.h"
#include <math.h>
#include "shapes.h"
#include "spaceship.h"
#include "bullet.h"
#include "explosions.h"

// Constructor that sets the ship to inactive so that it does not appear and sets the
// pointer to the Object manager to nullptr.
Spaceship::Spaceship()
{
	active = FALSE;
	pObjectManager = nullptr;
}

void Spaceship::Initalise(ObjectManager* objectManager)
{
	// sets the pointer to the temp object manager to that of the main objectmanager called om.
	pObjectManager = objectManager;
	// puts the image used for the ship into the draw engine class and places it into the image variable
	// so that the ship can then be later drawn.
	MyDrawEngine* pDE = MyDrawEngine::GetInstance();
	image = pDE->LoadPicture(L"spaceship.bmp");
	angle = 2.0f; 	// sets the angle to 2.0f.
	position.set(300, 300); // sets the spawn position of the ship to (300, 300) at the game start.
	shipVelocity.setBearing(angle, 0.5f); //sets the starting value for the shipVelocity using the ships angle.
	active = TRUE; // sets the ship to active so that it can be drawn.
}

void Spaceship::Update(float time)
{
	// obtains a .wav file from the resource files and places 
	// them inside the two respective variable of shootSound and thrustSound for later use.
	MySoundEngine* pSE = MySoundEngine::GetInstance();
	shootSound = pSE->LoadWav(L"shoot.wav");
	thrustSound = pSE->LoadWav(L"thrustloop2.wav");
	// samples the key board meaning that it takes whatever was pressed on the 
	// keyboard and stores it in the pInputs pointer.
	MyInputs* pInputs = MyInputs::GetInstance();
	pInputs->SampleKeyboard();
	//recalulates the shoot timer for later use to check if the ship can shoot again.
	shootDelayTimer	= shootDelayTimer - time;
	// sets the shoot timer to 0.35f this is the time between shots from the ship.
	shootDelay = 0.35f;
	//sets the front of the ships position.
	frontShip.setBearing(angle, 28.0f);
	// a series of logic checks to figure out if and when a certain key was pressed.
	if (pInputs->KeyPressed(DIK_W))
	{
		// if 'W' is pressed on the keyboard the ships moves forward. And a thrust
		// sound is played. The new ships velocity is worked out using the acceleration of the ship.
		shipAcceleration.setBearing(angle, 200.0f);
		shipVelocity = shipVelocity + shipAcceleration*time;
		pSE->Play(thrustSound);
	}
	if (pInputs->KeyPressed(DIK_S))
	{
		// if 'S' is pressed on the keyboard the ships moves backward. And a thrust
		// sound is played. The new ships velocity is worked out using the acceleration of the ship.
		shipAcceleration.setBearing(angle, -200.0f);
		shipVelocity = shipVelocity + shipAcceleration*time;
		pSE->Play(thrustSound);
	}
	if (pInputs->KeyPressed(DIK_A))
	{
		// if 'A' is pressed the ship rotates slowly so that the angle of tragectory can be changed.
		angle = angle + -0.01f;
	}
	if (pInputs->KeyPressed(DIK_D))
	{
		// if 'D' is pressed the ship rotates slowly so that the angle of tragectory can be changed.
		angle = angle + 0.01f;
	}
	// the ships friction is calculated based on its velocity, if the velocity is higher the ship decelerates faster.
	shipFriction = -0.8f * shipVelocity;
	// works out the new velocity based on the friction acting on the ship.
	shipVelocity = shipVelocity + shipFriction*time;
	// works out the ships new position.
	position = position + shipVelocity*time;
	if (pInputs->NewKeyPressed(DIK_SPACE) && shootDelayTimer <= 0)
	{
		//if the 'spacebar' is pressed the ship fires a bullet from the front of it, the bullets position
		//at spawn is worked out by using the ships front position before the ship is added to the ObjectManager.
		pSE->Play(shootSound);
		Vector2D bulletPosition = frontShip + position;
		Bullet* pNewBullet = new Bullet();
		pNewBullet->Initalise(bulletPosition, angle);
		// if the pointer to the bullet manager is empty the if statement will not fire.
		if (pObjectManager)
		{
			pObjectManager->AddObject(pNewBullet);
		}
		shootDelayTimer = shootDelay;
	}
	// places the ships hitbox at the ships position with radius 10.
	hitBox.PlaceAt(position, 10);
}

IShape2D* Spaceship::getShape()
{
	return &hitBox; //returns a reference to the hitbox of the bullet.
}

void Spaceship::ProcessCollision(GameObject* pOther)
{
	// if the ship collides with anyobjects such as the rock then it is destoryed.
	// this creates at explosion at the ships position
	Explosions* pExplosion = new Explosions();
	pExplosion->Initalise(position);
	// if the condition is met the explosion is added to the object manager.
	if (pObjectManager)
	{
		pObjectManager->AddObject(pExplosion);
	}
	// sets the ship to inactive making it disappear.
	active = FALSE;
}