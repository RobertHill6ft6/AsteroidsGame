// explosions.cpp
// Asteroid Game Engine version 1
// 15003814
// Last modified 07/01/2019

#include "gamecode.h"
#include "mydrawengine.h"
#include "mysoundengine.h"
#include "myinputs.h"
#include <time.h>
#include "gametimer.h"
#include "errorlogger.h"
#include <math.h>
#include "shapes.h"
#include "explosions.h"
#include "GameObject.h"

Explosions::Explosions()
{
	active = FALSE;// sets the explosion to active upon construction.
}

void Explosions::Initalise(Vector2D pos)
{
	MyDrawEngine* pDE = MyDrawEngine::GetInstance(); //initalises the DrawEngine ready to recive the image.
	active = TRUE; // sets the explosion to true.
	position = pos; // sets the position of the variable to the pos that is passed to it from where its called.
	currentImage = 0.0; // initalises the currentImage array position.
	picArray[0] = pDE->LoadPicture(L"explosion1.bmp"); // loads the image into the array one by one.
	picArray[1] = pDE->LoadPicture(L"explosion2.bmp");
	picArray[2] = pDE->LoadPicture(L"explosion3.bmp");
	picArray[3] = pDE->LoadPicture(L"explosion4.bmp");
	picArray[4] = pDE->LoadPicture(L"explosion5.bmp");
	picArray[5] = pDE->LoadPicture(L"explosion6.bmp");
	picArray[6] = pDE->LoadPicture(L"explosion7.bmp");
	picArray[7] = pDE->LoadPicture(L"explosion8.bmp");
}

void Explosions::Render()
{
	// if the explosion is active it draws the explosion at its current position in the array.
	if (active)
	{
		MyDrawEngine* pDE = MyDrawEngine::GetInstance();
		pDE->DrawAt(position, picArray[int(currentImage)]);
	}
}
void Explosions::Update(float time)
{
	// changes the current image that is to be drawn based on the frame time.
	currentImage = currentImage + 5.0f * time;
	// if the currentImage value is greater than 8 then the explosion is set to false.
	if (currentImage > 8)
	{
		active = FALSE;
	}
}

IShape2D* Explosions::getShape()
{
	return &hitBox; //returns a reference to the hitbox of the bullet.
}

void Explosions::ProcessCollision(GameObject* pOther)
{

}