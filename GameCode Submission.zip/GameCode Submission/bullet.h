// bullet.h
// Asteroid Game Engine version 1
// 15003814
// Last modified 07/01/2019

#pragma once
#include "errortype.h"
#include "windows.h"
#include "mydrawengine.h"
#include "mysoundengine.h"
#include "gametimer.h"
#include "GameObject.h"
#include "bulletpool.h"

//A GameObject Sub Class for the bullets in the game
class Bullet : public GameObject
{
private:
	Vector2D bulletVelocity; //Contains the velocity for the bullet both speed and direction
	float bulletSpeed; //Value to hold the Speed of the bullet
	float bulletTime; //Value to hold the length of time  between bullets being fired.
	Circle2D hitBox; // The collision detection box for the bullet.
	static const int MAXBULLETS = 10; // max number of bullets that can be on screen at once.
	static BulletPool s_pool; // a static pool for the bullets.

public:
	Bullet(); //Constructor for Bullet
	void Initalise(Vector2D pos, float startAngle); //function to give the bullet its inital 
	//values such as its position speed angle etc.
	void Update(float time); //function to update the values relavent to the bullet, with time giving update information in regards to the frame time.
	IShape2D* getShape(); // function to return the memory location of a IShape2D.
	void ProcessCollision(GameObject* pOther); // function to process a collion between 2 objects in the game.
	void* Bullet::operator new(size_t s) // overload new functionwhich calls the allocate function so that the memory manager is used.
	{
		return(s_pool.Allocate());
	}
	void Bullet::operator delete(void* pItem)// overload delete function which calls the free function so that the memory manager is used.
	{
		s_pool.Free((Bullet*)pItem);
	}
};