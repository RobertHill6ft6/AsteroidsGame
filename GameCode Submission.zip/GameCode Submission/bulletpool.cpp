// bulletpool.cpp
// Asteroid Game Engine version 1
// 15003814
// Last modified 07/01/2019

#include "bulletpool.h"
#include "bullet.h"


BulletPool::BulletPool(int iNumBullet)
{
	m_BulletStore = (Bullet*)operator new (sizeof(Bullet) *iNumBullet); // overloads the new operator
	// replacing it with this new one where it preallocates the number of memory slots required.
	// for loop to cycle through the vector to promise it the bullets that it will be reciveing.
	for (int i = 0; i < iNumBullet; i++)
	{
		m_FreeBullet.push_back(m_BulletStore + i);
	}
}

BulletPool::~BulletPool()
{
	//overloads the delete operator and deletes everything from the bullet store.
	operator delete(m_BulletStore);
}

Bullet* BulletPool::Allocate()
{
	//This places the bullet that is wanting to be placed in memory into memory
	//on the stack and allocates it a location in memory.
	Bullet* pBullet = m_FreeBullet.back();
	m_FreeBullet.pop_back(); 
	return pBullet;
}

void BulletPool::Free(Bullet* pBullet)
{
	// frees the memory space in the stack so that another
	// memory bullet/object can take its place.
	m_FreeBullet.push_back(pBullet);
}

void BulletPool::FreeAll()
{
	// Frees up the entire stack of memory.
	m_FreeBullet.push_back(m_BulletStore);
}
