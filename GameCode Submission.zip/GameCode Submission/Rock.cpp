// Rock.cpp
// Asteroid Game Engine version 1
// 15003814
// Last modified 07/01/2019

#include "gamecode.h"
#include "mydrawengine.h"
#include "mysoundengine.h"
#include "myinputs.h"
#include <time.h>
#include "gametimer.h"
#include "errorlogger.h"
#include <math.h>
#include "shapes.h"
#include "Rock.h"
#include "cstdlib"
#include "Explosions.h"
#include "GameObject.h"


Rock::Rock()
{
	active = FALSE; // upon construction sets the rock as inactive.
	pObjectManager = nullptr; // upon consturction also sets the pointer to the om to a nullptr to initalise it.
}

void Rock::Initalise(ObjectManager* objectManager)
{
	// sets the pointer to the om to the pointer of the om 
	// that is passed to the rock.
	pObjectManager = objectManager;
	angle = rand() % 628 / 100.0f;// chooses a random angle in radians that the rocks will spawn in to move.
	MyDrawEngine* pDE = MyDrawEngine::GetInstance();
	image = pDE->LoadPicture(L"rock1.bmp");
	//sets the position bearing of the rocks according to a random value calculation.
	position.setBearing(rand() % 628/100.0f, rand() % 600 + 400.0f);
	// does the same for the rocks velocity as it does for position.
	rockVelocity.setBearing(rand() % 628 / 100.0f, 4.0f);
	active = TRUE; // sets the active of the rock to true.
}


void Rock::Update(float time)
{
	// works out the new position of the rocks using frame time.
	position = position + rockVelocity*time;
	hitBox.PlaceAt(position, 50); // places a hitbox on the rock at the same position with a set radius. 
}

IShape2D* Rock::getShape()
{
	return &hitBox; // returns the game objects
}

void Rock::ProcessCollision(GameObject* pOther)
{
	// checks if the rock has colided with another rock. 
	// If it has then nothing will happen.
	if (typeid(*pOther) == typeid(Rock))
	{

	}
	// if it is not a rock then the rock is set as inactive, it also creates a new explosion
	// at the place where the rock was destoryed.
	else
	{
		active = FALSE;
		Explosions* pExplosion = new Explosions();
		pExplosion->Initalise(position);
		if (pObjectManager)
		{
			pObjectManager->AddObject(pExplosion);
		}
	}
}
