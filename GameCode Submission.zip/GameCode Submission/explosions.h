#pragma once
#include "errortype.h"
#include "windows.h"
#include "mydrawengine.h"
#include "mysoundengine.h"
#include "gametimer.h"
#include "GameObject.h"

//Explosions sub class of gameObject for the explosions that take place in the game.
class Explosions : public GameObject
{
private:
	PictureIndex picArray[8]; // An array of pictures to hold each of the frames of the explosion.
	float currentImage; // hold the current location in the array that the image should be displayed.
	Vector2D explosionPosition; // The position that the explosion should be drawn at.
	Circle2D hitBox; // variable to hold the information on the explosions hitbox.

public:
	Explosions();
	void Initalise(Vector2D pos);
	void Render();
	void Update(float time);
	IShape2D* getShape();
	void ProcessCollision(GameObject* pOther);
};