// bulletpool.h
// Asteroid Game Engine version 1
// 15003814
// Last modified 07/01/2019
#pragma once
#include <vector>

class Bullet;
class BulletPool
{
private:
	std::vector<Bullet*> m_FreeBullet; // a stack of gameobjects that would be used to put things into the memory of the stack.
	Bullet* m_BulletStore; // a pointer to a bullet

public:
	BulletPool(int iNumBullets); // constructor for the bulletPool, sets the pool size here. 
	~BulletPool(); // Desconstructor for the pool simply deletes the pool.
	Bullet* Allocate(); // function that places an object into the pool when it is called.
	void Free(Bullet* pBullet); // frees the memory block in the stack up when the object placed inside it is no longer needed.
	void FreeAll(); // frees the entire block of memory in the stack.
};