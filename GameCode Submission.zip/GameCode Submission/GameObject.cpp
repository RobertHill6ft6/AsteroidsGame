// GameObject.cpp
// Asteroid Game Engine version 1
// 15003814
// Last modified 07/01/2019

#include "gamecode.h"
#include "mydrawengine.h"
#include "mysoundengine.h"
#include "myinputs.h"
#include <time.h>
#include "gametimer.h"
#include "errorlogger.h"
#include <math.h>
#include "shapes.h"
#include "GameObject.h"

GameObject::GameObject()
{

}

GameObject::~GameObject()
{

}

void GameObject::Render()
{
	if (active == TRUE)
	{
		MyDrawEngine* pDE = MyDrawEngine::GetInstance();
		pDE->DrawAt(position, image, 1.0f, angle, 0.0f);
	}
	else
	{

	}
}

bool GameObject::isActive()
{
	return active;
}
