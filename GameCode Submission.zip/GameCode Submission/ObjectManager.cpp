// ObjectManager.cpp
// Asteroid Game Engine version 1
// 15003814
// Last modified 07/01/2019

#include "errorlogger.h"
#include <math.h>
#include "shapes.h"
#include "spaceship.h"
#include "bullet.h"
#include "gametimer.h"
#include "GameObject.h"
#include "ObjectManager.h"
#include <algorithm>

ObjectManager::ObjectManager()
{

}

ObjectManager::~ObjectManager()
{

}

void ObjectManager::AddObject(GameObject* pNewObject)
{
	pobjects.push_back(pNewObject);
	//adds the object that is passed to Add Object to the Object managers list.
}

void ObjectManager::UpdateAll(float time)
{
	std::list<GameObject*>::iterator it;
	// creates an iterator to go through each object within the list one by one
	// and do something with it. The something is handled inside the for loop.
	for (it = pobjects.begin(); it != pobjects.end(); it++)
	{
			(*it)->Update(time);
			//updates the Objects in the list that is at the position of the iterator.
	}
}

void ObjectManager::RenderAll()
{
	std::list<GameObject*>::iterator it;
	// creates an iterator to go through each object within the list one by one
	// and do something with it. The something is handled inside the for loop.
	for (it = pobjects.begin(); it != pobjects.end(); it++)
	{
			(*it)->Render();
			//renders the Objects in the list that is at the position of the iterator.
	}
}

void ObjectManager::DeleteAll()
{
	// for loop which takes each of the objects in the list of objects and goes through each one.
	for (GameObject* &nextObjectPointer : pobjects) // The & is critical. Check.
	{
		//if the realtive object is not active then the object and its 
		//pointer will be delted and its pointer set to null
			delete nextObjectPointer;
			nextObjectPointer = nullptr; // Always do this when deleting! 
	}
	//clears the objects themselves from the list.
	pobjects.clear();
}

void ObjectManager::DeleteInactive() 
{
	// for loop which takes each of the objects in the list of objects and goes through each one.
	for (GameObject* &nextObjectPointer : pobjects) // The & is critical. Check.
	{
		//if the realtive object is not active then the object and its 
		//pointer will be delted and its pointer set to null
		if (nextObjectPointer->isActive() == false)
		{
			delete nextObjectPointer;
			nextObjectPointer = nullptr; // Always do this when deleting! 
		}
	}
	//removes all objects in the object managers list that are set as nullptr
	//and erases the objects within.
	auto it = std::remove(pobjects.begin(), pobjects.end(), nullptr);
	pobjects.erase(it, pobjects.end());
}

void ObjectManager::CheckAllCollisions()
{
	// creates two gameObject iterators for cycling through the list of objects.
	std::list<GameObject*>::iterator it1;
	std::list<GameObject*>::iterator it2;
	// finds the objects in iterator 1 and iterator 2 comapres if the shapes relavent
	// to them has been intersected by the other, if one has occured then the collision on
	// each object is processed, if not it keeps cycling until all objects are checked.
	for (it1 = pobjects.begin(); it1 != pobjects.end(); it1++)
	{
		for (it2 = std::next(it1);it2 != pobjects.end(); it2++)
		{
			if ((*it1)->getShape()->Intersects(*((*it2)->getShape())))
			{
				(*it1)->ProcessCollision((*it2));
				(*it2)->ProcessCollision((*it1));
				// Do something 
			}
		}
	}
}